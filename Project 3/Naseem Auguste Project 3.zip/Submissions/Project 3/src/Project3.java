/*  Name:  Naseem Auguste
     Course: CNT 4714 – Fall 2022 
     Assignment title: Project 3 – Two-Tier Client-Server Application Development With MySQL and JDBC
     Date: Wednesday November 2, 2022 
*/ 

import java.io.FileNotFoundException;

public class Project3 
{

	public static void main(String[] args) throws FileNotFoundException 
	{

		new myFrame();

	}

}
