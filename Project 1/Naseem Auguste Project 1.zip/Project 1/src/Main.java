/*  Name:  Naseem Auguste
     Course: CNT 4714 – Fall 2022 
     Assignment title: Project 1 – Event-driven Enterprise Simulation 
     Date: Sunday September 11, 2022 
*/ 


import java.io.FileNotFoundException;


public class Main 
{
	public static void main(String[] args) throws FileNotFoundException 
	{
		new myFrame();

		
		
		
	}
}