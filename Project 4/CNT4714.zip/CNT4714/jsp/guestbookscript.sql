#script to create a database for jsp guestbook login example

CREATE DATABASE IF NOT EXISTS guestbook;

USE guestbook;

DROP TABLE IF EXISTS guests;

CREATE TABLE guests (
	lastName varchar (20),
	firstName varchar (20),
	email varchar(50),
	PRIMARY KEY (email)
);


select *
from guests;

