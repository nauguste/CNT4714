// GuestDataBean.java
// Class GuestDataBean makes a database connection and supports 
// inserting and retrieving data from the database.  Database created with guestbookscript.sql
package beans;

import java.sql.SQLException;
import javax.sql.rowset.*;
import com.mysql.cj.jdbc.MysqlDataSource;
//import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.util.ArrayList;
//import com.sun.rowset.CachedRowSetImpl;  //Sun's CachedRowSet implementation


public class GuestDataBean 
{
   private CachedRowSet rowSet;
   MysqlDataSource dataSource = null;
  
   // construct TitlesBean object 
   public GuestDataBean() throws Exception
   {
      // load the MySQL driver
	  // dataSource = new MysqlDataSource();
        Class.forName("com.mysql.jdbc.Driver");
     // dataSource = new MysqlDataSource();
      // specify properties of CachedRowSet
      //rowSet = new CachedRowSetImpl();  
      rowSet = RowSetProvider.newFactory().createCachedRowSet();  
	 // rowSet = RowSetProvider.newFactory("com.mysql.jdbc.Driver", null).createCachedRowSet();
      rowSet.setUrl( "jdbc:mysql://localhost:3306/guestbook" ); 
      rowSet.setUsername( "root" );
      rowSet.setPassword( "rootMAC1$" );

	  // obtain list of titles
      rowSet.setCommand( "SELECT firstName, lastName, email FROM guests" );
      rowSet.execute();
   } // end GuestDataBean constructor

   // return an ArrayList of GuestBeans
   public ArrayList< GuestBean > getGuestList() throws SQLException
   {
      ArrayList< GuestBean > guestList = new ArrayList< GuestBean >();

      rowSet.beforeFirst(); // move cursor before the first row

      // get row data
      while ( rowSet.next() ) 
      {
         GuestBean guest = new GuestBean();

         guest.setFirstName( rowSet.getString( 1 ) );
         guest.setLastName( rowSet.getString( 2 ) );
         guest.setEmail( rowSet.getString( 3 ) );

         guestList.add( guest ); 
      } // end while

      return guestList;
   } // end method getGuestList
   
   // insert a guest in guestbook database
   public void addGuest( GuestBean guest ) throws SQLException
   {
      rowSet.moveToInsertRow(); // move cursor to the insert row

      // update the three columns of the insert row 
      rowSet.updateString( 1, guest.getFirstName() ); 
      rowSet.updateString( 2, guest.getLastName() ); 
      rowSet.updateString( 3, guest.getEmail() ); 
      rowSet.insertRow(); // insert row to rowSet
      rowSet.moveToCurrentRow(); // move cursor to the current row
      rowSet.acceptChanges(); // propagate changes to database
   } // end method addGuest
} // end class GuestDataBean


 